/**
 * Simple, dependency-free test runner for batching.js
 * Run with: node test/test-batching.js
 */
const path = require('path');
const { createEngine } = require(path.join(__dirname, '..', 'js', 'batching.js'));

let pass = 0;
let fail = 0;

function assert(cond, msg) {
  if (cond) {
    pass += 1;
    console.log('  \x1b[32m✓\x1b[0m ' + msg);
  } else {
    fail += 1;
    console.log('  \x1b[31m✗ FAILED:\x1b[0m ' + msg);
  }
}

function section(title) {
  console.log('\n\x1b[36m' + title + '\x1b[0m');
}

// ---------------------------------------------------------------------
section('1) Basic zone grouping');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  engine.addOrder({ zone: 'North', customerName: 'Asha', itemCount: 2 }, t);
  engine.addOrder({ zone: 'South', customerName: 'Ravi', itemCount: 2 }, t);
  const state = engine.getState();
  assert(state.North.length === 1, 'North has exactly 1 batch');
  assert(state.South.length === 1, 'South has exactly 1 batch');
  assert(state.North[0].orders.length === 1, 'North batch has 1 order');
}

// ---------------------------------------------------------------------
section('2) Capacity split: batch auto-splits when >5 items');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  engine.addOrder({ zone: 'North', customerName: 'A', itemCount: 3 }, t);
  engine.addOrder({ zone: 'North', customerName: 'B', itemCount: 3 }, t); // 3+3=6 > 5 -> split
  const state = engine.getState();
  assert(state.North.length === 2, 'A second batch was created for North');
  assert(state.North[0].totalItems === 3, 'First batch capped at 3 items (not overfilled)');
  assert(state.North[0].status === 'ready', 'First batch closed due to capacity_full');
  assert(state.North[0].closedReason === 'capacity_full', 'Close reason recorded correctly');
  assert(state.North[1].totalItems === 3, 'Second batch received the overflow order');
  assert(state.North[1].status === 'open', 'Second batch still open');
}

// ---------------------------------------------------------------------
section('3) Capacity split: exact-fit does NOT split');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  engine.addOrder({ zone: 'East', itemCount: 2 }, t);
  engine.addOrder({ zone: 'East', itemCount: 3 }, t); // 2+3 = 5, exactly at limit
  const state = engine.getState();
  assert(state.East.length === 1, 'Still just 1 batch when exactly at capacity (5/5)');
  assert(state.East[0].totalItems === 5, 'Batch total is exactly 5');
}

// ---------------------------------------------------------------------
section('4) Time window: batch auto-closes after 5 minutes');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  engine.addOrder({ zone: 'West', itemCount: 1 }, t);
  t = 4 * 60 * 1000; // 4 min later, still within window
  engine.addOrder({ zone: 'West', itemCount: 1 }, t);
  let state = engine.getState();
  assert(state.West.length === 1, 'Still 1 batch at 4 minutes (within 5-min window)');

  t = 5 * 60 * 1000 + 1; // just past 5 min from batch start
  engine.tick(t);
  state = engine.getState();
  assert(state.West[0].status === 'ready', 'Batch closed once window elapsed');
  assert(state.West[0].closedReason === 'window_expired', 'Correct close reason: window_expired');

  engine.addOrder({ zone: 'West', itemCount: 1 }, t);
  state = engine.getState();
  assert(state.West.length === 2, 'New batch opened for West after window expiry');
}

// ---------------------------------------------------------------------
section('5) Zones are independent of each other');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  engine.addOrder({ zone: 'Central', itemCount: 5 }, t);
  engine.addOrder({ zone: 'Central', itemCount: 1 }, t); // triggers split in Central only
  engine.addOrder({ zone: 'South', itemCount: 1 }, t);
  const state = engine.getState();
  assert(state.Central.length === 2, 'Central split into 2 batches');
  assert(state.South.length === 1, 'South unaffected by Central batching');
}

// ---------------------------------------------------------------------
section('6) markDispatched updates status correctly');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  const { batch } = engine.addOrder({ zone: 'North', itemCount: 2 }, t);
  t = 5 * 60 * 1000 + 1;
  engine.tick(t);
  const dispatched = engine.markDispatched(batch.id, t);
  assert(dispatched.status === 'dispatched', 'Batch status becomes dispatched');
  assert(dispatched.closedReason === 'dispatched', 'closedReason updated to dispatched');
}

// ---------------------------------------------------------------------
section('7) Stats aggregation is correct');
{
  let t = 0;
  const engine = createEngine({ clock: () => t });
  engine.addOrder({ zone: 'North', itemCount: 3 }, t);
  engine.addOrder({ zone: 'North', itemCount: 3 }, t); // split -> 2 batches
  engine.addOrder({ zone: 'South', itemCount: 2 }, t);
  const stats = engine.getStats();
  assert(stats.totalOrders === 3, 'Total orders = 3');
  assert(stats.totalBatches === 3, 'Total batches = 3 (2 North + 1 South)');
  assert(stats.activeBatches === 2, 'Active (open) batches = 2');
}

// ---------------------------------------------------------------------
console.log('\n' + '-'.repeat(50));
if (fail === 0) {
  console.log(`\x1b[32mALL ${pass} TESTS PASSED\x1b[0m`);
  process.exit(0);
} else {
  console.log(`\x1b[31m${fail} TEST(S) FAILED\x1b[0m, ${pass} passed`);
  process.exit(1);
}

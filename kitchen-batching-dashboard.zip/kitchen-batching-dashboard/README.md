# 🍳 KitchenBatch — Capacity-Constrained Kitchen Order Batching

**Built for SpeedCode 2026 · Nitte Meenakshi Institute of Technology, Bengaluru**

A live dashboard that solves a real kitchen-ops problem: as delivery orders stream in, group them
by **delivery zone** into batches so a rider can pick up several orders on one run — but never let a
batch grow beyond what a rider can realistically carry.

> **Group orders by zone, within a 5-minute window, capped at 5 items per batch.
> The instant a batch would exceed capacity, automatically split the overflow into a fresh batch for the same zone.**

---

## ✨ Why this matters

Cloud kitchens and dark stores lose money two ways: sending a rider out with a single order (low
efficiency), or trying to cram too many orders onto one trip (spoiled food, late deliveries, unhappy
customers). KitchenBatch automates the middle ground — a deterministic, testable rule engine that a
real kitchen ops team could plug straight into their order pipeline.

---

## 🧠 The algorithm

Each **zone** (delivery area) maintains its own sequence of batches. For every incoming order:

1. **Find the zone's current open batch.** If none exists, open one.
2. **Time check** — if more than **5 minutes** have passed since the batch opened, close it
   (`window_expired`, status → `ready`) and open a fresh batch.
3. **Capacity check** — if adding this order's items would push the batch over **5 items total**,
   close the current batch (`capacity_full`, status → `ready`) and open a **new batch for the same
   zone**, then place the order there instead.
4. Otherwise, add the order to the currently open batch.
5. A background tick also closes any batch whose 5-minute window elapses even without new orders
   arriving, so nothing sits open forever.
6. Ready batches can be **manually marked "Dispatched"** once a rider picks them up.

This logic lives in one dependency-free file — [`js/batching.js`](js/batching.js) — decoupled from
the UI, and is fully unit tested (see below).

### Design decisions worth mentioning to judges
- **Zone-scoped batches** are fully independent — a capacity split in one zone never affects another.
- **Splitting never overfills a batch.** Order sequencing is preserved: the order that breaks the
  limit is never merged into the full batch — it's the seed of the next one.
- **Exact-fit doesn't split** (5/5 items stays as one batch) — capacity is a hard ceiling, not a
  soft trigger.
- The engine accepts an injectable `clock`, which is what makes it possible to unit test 5-minute
  window behavior in milliseconds instead of waiting in real time.

---

## 🚀 Running it in GitHub Codespaces

1. Unzip this project and push it to a new GitHub repo (or drag the files straight into an existing
   repo).
2. Open the repo in a **Codespace**. `.devcontainer/devcontainer.json` is pre-configured — Node is
   ready out of the box.
3. In the Codespace terminal:
   ```bash
   npm start
   ```
4. Codespaces will prompt to open the forwarded port (**5173**) — click **Open in Browser**.
   That's it — zero build step, zero frontend framework, zero flaky installs.

### Running locally (outside Codespaces)
```bash
npm start
# or, with no npm at all:
python3 -m http.server 5173
```
Then visit `http://localhost:5173`.

### Running the test suite
```bash
npm test
```
This runs 22 assertions against the batching engine (zone grouping, capacity splitting, window
expiry, independent zones, dispatch flow, and stats aggregation) — all passing.

---

## 🖥️ Using the dashboard

- **▶ Start Live Simulation** — spins up a realistic order stream (random zone, customer, and
  Indian-menu items) every couple of seconds, so the board fills up live during a demo.
- **Place a New Order** panel — manually submit an order to a specific zone with hand-picked items,
  to demonstrate the splitting rule on demand (e.g. add two 3-item orders to the same zone back to
  back and watch it split).
- Each **batch card** shows:
  - a live item-capacity bar (`x / 5`)
  - a countdown to the 5-minute window close
  - the orders inside it
  - its status: **Open** (still accepting orders) → **Ready** (closed, awaiting pickup) →
    **Dispatched** (picked up)
- A **⚠ split tag** appears on any batch that was closed specifically because capacity was hit,
  making the auto-split behavior visible at a glance — great for a live demo.
- The **stats strip** at the top aggregates total orders, total batches, active/ready/dispatched
  counts, and average items per batch in real time.

---

## 🗂️ Project structure

```
kitchen-batching-dashboard/
├── index.html                 # App shell
├── css/style.css              # Dark glassmorphism dashboard theme
├── js/
│   ├── batching.js            # Core engine — zone/window/capacity logic (framework-free)
│   ├── data.js                 # Zone metadata + demo menu/names
│   └── app.js                  # Rendering, simulation, form handling
├── test/test-batching.js      # 22 unit tests for the engine (run with `node test/test-batching.js`)
├── .devcontainer/devcontainer.json
├── package.json
└── README.md
```

No build tools, no bundler, no framework lock-in — the whole thing runs from static files, which
means it's trivial to extend, review, and demo without worrying about install failures on stage.

---

## 🔮 Future scope

- Persist batches to a backend (Node/Express + SQLite or Postgres) for multi-device kitchen displays.
- Configurable capacity per zone (e.g. bigger batches for zones with larger delivery bags).
- Rider assignment layer once a batch is marked ready.
- Priority orders that bypass the window (e.g. "ASAP" flag) to skip queuing.
- Push notifications to kitchen staff when a batch is ready.

---

## 🏆 Built for SpeedCode 2026

Organized by **Nitte Meenakshi Institute of Technology, Bengaluru**.

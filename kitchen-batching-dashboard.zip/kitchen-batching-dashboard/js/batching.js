/**
 * batching.js
 * -----------------------------------------------------------------------
 * Core engine for Capacity-Constrained Kitchen Batching.
 *
 * Rules implemented:
 *  1. Orders are grouped by ZONE.
 *  2. Within a zone, orders are grouped into a BATCH if they arrive within
 *     a rolling WINDOW_MS (default 5 minutes) of the batch's start time.
 *  3. Each batch has a hard capacity (default 5 items). If adding an
 *     incoming order would push the batch's total item count above the
 *     capacity, the current batch is closed ("capacity_full") and a NEW
 *     batch is opened for that same zone to receive the order.
 *  4. If a batch's window elapses (5 minutes pass with no capacity
 *     breach), it is automatically closed ("window_expired") and marked
 *     ready for pickup/dispatch.
 *  5. Batches can be manually marked "dispatched" once picked up.
 *
 * This file uses a UMD-ish export so the exact same logic can be:
 *   - loaded in the browser as a plain <script> (attaches window.Batching)
 *   - required in Node for unit testing (module.exports)
 * -----------------------------------------------------------------------
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.Batching = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const ZONES = ['North', 'South', 'East', 'West', 'Central'];
  const WINDOW_MS = 5 * 60 * 1000; // 5 minutes
  const MAX_ITEMS_PER_BATCH = 5;

  function createEngine(options = {}) {
    const windowMs = options.windowMs || WINDOW_MS;
    const maxItems = options.maxItems || MAX_ITEMS_PER_BATCH;
    const clock = options.clock || (() => Date.now());

    let batchSeq = 0;
    let orderSeq = 0;

    /** zone -> array of batches (in chronological order) */
    const batchesByZone = {};
    ZONES.forEach((z) => (batchesByZone[z] = []));

    function newBatch(zone, t) {
      batchSeq += 1;
      const batch = {
        id: 'B' + batchSeq,
        seq: batchesByZone[zone].length + 1, // e.g. Batch #1, #2 for that zone
        zone,
        orders: [],
        totalItems: 0,
        windowStart: t,
        windowEnd: t + windowMs,
        status: 'open', // 'open' | 'ready' | 'dispatched'
        closedAt: null,
        closedReason: null // 'capacity_full' | 'window_expired' | 'dispatched'
      };
      batchesByZone[zone].push(batch);
      return batch;
    }

    function closeBatch(batch, reason, t) {
      if (batch.status !== 'open' && reason !== 'dispatched') return;
      batch.status = reason === 'dispatched' ? 'dispatched' : 'ready';
      batch.closedAt = t;
      batch.closedReason = reason;
    }

    function getOpenBatch(zone) {
      const arr = batchesByZone[zone];
      const last = arr[arr.length - 1];
      return last && last.status === 'open' ? last : null;
    }

    /** Close any batches whose 5-minute window has elapsed. Call on every tick. */
    function tick(t) {
      t = t == null ? clock() : t;
      ZONES.forEach((zone) => {
        const batch = getOpenBatch(zone);
        if (batch && t - batch.windowStart >= windowMs) {
          closeBatch(batch, 'window_expired', t);
        }
      });
      return t;
    }

    function addOrder(orderInput, t) {
      t = t == null ? clock() : t;
      tick(t);

      const zone = orderInput.zone;
      if (!ZONES.includes(zone)) {
        throw new Error('Invalid zone: ' + zone);
      }

      orderSeq += 1;
      const itemCount =
        orderInput.itemCount != null
          ? orderInput.itemCount
          : (orderInput.items || []).reduce((s, i) => s + (i.qty || 1), 0);

      const order = {
        id: 'O' + orderSeq,
        zone,
        customerName: orderInput.customerName || 'Guest',
        items: orderInput.items || [],
        itemCount,
        createdAt: t
      };

      let batch = getOpenBatch(zone);
      if (!batch) {
        batch = newBatch(zone, t);
      }

      // Capacity check -> auto-split into a fresh batch for the same zone
      if (batch.totalItems + itemCount > maxItems && batch.orders.length > 0) {
        closeBatch(batch, 'capacity_full', t);
        batch = newBatch(zone, t);
      }

      batch.orders.push(order);
      batch.totalItems += itemCount;

      return { order, batch };
    }

    function markDispatched(batchId, t) {
      t = t == null ? clock() : t;
      for (const zone of ZONES) {
        const b = batchesByZone[zone].find((x) => x.id === batchId);
        if (b) {
          closeBatch(b, 'dispatched', t);
          return b;
        }
      }
      return null;
    }

    function getState() {
      tick();
      return batchesByZone;
    }

    function getStats() {
      let totalOrders = 0;
      let totalBatches = 0;
      let activeBatches = 0;
      let readyBatches = 0;
      let dispatchedBatches = 0;
      let fullCapacityBatches = 0;
      let totalItemsAll = 0;

      ZONES.forEach((zone) => {
        batchesByZone[zone].forEach((b) => {
          totalBatches += 1;
          totalOrders += b.orders.length;
          totalItemsAll += b.totalItems;
          if (b.status === 'open') activeBatches += 1;
          if (b.status === 'ready') readyBatches += 1;
          if (b.status === 'dispatched') dispatchedBatches += 1;
          if (b.totalItems >= maxItems) fullCapacityBatches += 1;
        });
      });

      return {
        totalOrders,
        totalBatches,
        activeBatches,
        readyBatches,
        dispatchedBatches,
        avgItemsPerBatch: totalBatches ? (totalItemsAll / totalBatches).toFixed(2) : '0.00',
        capacityUtilization: totalBatches
          ? ((fullCapacityBatches / totalBatches) * 100).toFixed(1)
          : '0.0'
      };
    }

    return {
      ZONES,
      MAX_ITEMS: maxItems,
      WINDOW_MS: windowMs,
      addOrder,
      tick,
      getState,
      getStats,
      markDispatched
    };
  }

  return { ZONES, WINDOW_MS, MAX_ITEMS_PER_BATCH, createEngine };
});

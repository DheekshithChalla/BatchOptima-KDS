(function () {
  'use strict';

  const engine = Batching.createEngine(); // real 5-min window + 5-item cap
  const { ZONE_META, MENU, NAMES } = window.DashboardData;

  // ---------------- DOM refs ----------------
  const zonesBoardEl = document.getElementById('zones-board');
  const statsEl = document.getElementById('stats-grid');
  const clockEl = document.getElementById('clock');
  const toastStack = document.getElementById('toast-stack');
  const simToggleBtn = document.getElementById('sim-toggle');
  const resetBtn = document.getElementById('reset-btn');
  const orderForm = document.getElementById('order-form');
  const chipRow = document.getElementById('item-chip-row');
  const selectedCountEl = document.getElementById('selected-count');

  // ---------------- Build zone columns (static shell, content re-rendered) ----------------
  function buildZoneColumns() {
    zonesBoardEl.innerHTML = '';
    Batching.ZONES.forEach((zoneKey) => {
      const meta = ZONE_META[zoneKey];
      const col = document.createElement('div');
      col.className = 'zone-column';
      col.style.setProperty('--zone-color', meta.color);
      col.id = 'zone-col-' + zoneKey;
      col.innerHTML = `
        <div class="zone-header">
          <div class="zone-title">
            <span class="zone-dot"></span>
            <div>
              <h4>${meta.label}</h4>
              <span>${meta.sub}</span>
            </div>
          </div>
          <div class="zone-count" id="zone-count-${zoneKey}">0 batches</div>
        </div>
        <div class="batch-list" id="batch-list-${zoneKey}"></div>
      `;
      zonesBoardEl.appendChild(col);
    });
  }

  // ---------------- Item chip selector for manual form ----------------
  const selectedItems = {}; // name -> qty
  function buildChips() {
    chipRow.innerHTML = '';
    MENU.forEach((name) => {
      const chip = document.createElement('div');
      chip.className = 'item-chip';
      chip.dataset.name = name;
      chip.innerHTML = `${name}`;
      chip.addEventListener('click', () => {
        const current = selectedItems[name] || 0;
        const next = current >= 3 ? 0 : current + 1; // cycle 0 -> 1 -> 2 -> 3 -> 0
        if (next === 0) delete selectedItems[name];
        else selectedItems[name] = next;
        renderChipState();
      });
      chipRow.appendChild(chip);
    });
  }

  function renderChipState() {
    let totalCount = 0;
    [...chipRow.children].forEach((chip) => {
      const name = chip.dataset.name;
      const qty = selectedItems[name] || 0;
      totalCount += qty;
      chip.classList.toggle('selected', qty > 0);
      chip.innerHTML = qty > 0 ? `${name} <span class="qty-badge">${qty}</span>` : name;
    });
    selectedCountEl.innerHTML = `<b>${totalCount}</b> item${totalCount === 1 ? '' : 's'} selected`;
  }

  // ---------------- Helpers ----------------
  function fmtTime(ms) {
    const d = new Date(ms);
    return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  }

  function fmtCountdown(remainMs) {
    if (remainMs <= 0) return '00:00';
    const totalSec = Math.floor(remainMs / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function toast(msg, cls) {
    const el = document.createElement('div');
    el.className = 'toast' + (cls ? ' ' + cls : '');
    el.textContent = msg;
    toastStack.appendChild(el);
    setTimeout(() => el.remove(), 3600);
  }

  // ---------------- Rendering ----------------
  function render() {
    const state = engine.getState();
    const now = Date.now();

    Batching.ZONES.forEach((zoneKey) => {
      const batches = state[zoneKey];
      const listEl = document.getElementById('batch-list-' + zoneKey);
      const countEl = document.getElementById('zone-count-' + zoneKey);
      countEl.textContent = `${batches.length} batch${batches.length === 1 ? '' : 'es'}`;

      if (batches.length === 0) {
        listEl.innerHTML = `<div class="empty-zone">No orders yet.<br>Waiting for incoming orders…</div>`;
        return;
      }

      // newest batch first for visibility, but keep stable order otherwise
      const ordered = [...batches].reverse();

      listEl.innerHTML = ordered
        .map((batch) => {
          const pct = Math.min(100, (batch.totalItems / engine.MAX_ITEMS) * 100);
          const isFull = batch.totalItems >= engine.MAX_ITEMS;
          const remain = batch.windowEnd - now;

          let statusHtml = '';
          if (batch.status === 'open') {
            statusHtml = `<span class="status-badge open"><span class="pulse-dot"></span>Open</span>`;
          } else if (batch.status === 'ready') {
            statusHtml = `<span class="status-badge ready">Ready</span>`;
          } else {
            statusHtml = `<span class="status-badge dispatched">✓ Dispatched</span>`;
          }

          const splitTag =
            batch.closedReason === 'capacity_full'
              ? `<span class="split-tag">⚠ split — capacity limit reached (5 items)</span>`
              : '';

          const windowHtml =
            batch.status === 'open'
              ? `<div class="window-row">⏱ window closes in <span class="timer">${fmtCountdown(remain)}</span></div>`
              : `<div class="window-row">closed at ${fmtTime(batch.closedAt)} · ${
                  batch.closedReason === 'capacity_full' ? 'capacity full' : batch.closedReason === 'dispatched' ? 'dispatched' : 'window expired'
                }</div>`;

          const ordersHtml = batch.orders
            .map((o) => {
              const itemSummary = o.items.map((i) => (i.qty > 1 ? `${i.name} ×${i.qty}` : i.name)).join(', ');
              return `<div class="order-line"><span class="cust">${o.customerName}</span><span class="items">${itemSummary || o.itemCount + ' item(s)'}</span></div>`;
            })
            .join('');

          const dispatchBtn =
            batch.status === 'ready'
              ? `<button class="btn btn-ghost btn-small mark-dispatched" data-id="${batch.id}">✓ Mark Dispatched</button>`
              : '';

          return `
            <div class="batch-card status-${batch.status}" data-batch-id="${batch.id}">
              <div class="batch-top">
                <div class="batch-name">Batch #${batch.seq}</div>
                ${statusHtml}
              </div>
              ${splitTag}
              <div class="capacity-row">
                <div class="capacity-label"><span>Items</span><span>${batch.totalItems} / ${engine.MAX_ITEMS}</span></div>
                <div class="capacity-bar-track"><div class="capacity-bar-fill ${isFull ? 'full' : ''}" style="width:${pct}%"></div></div>
              </div>
              ${windowHtml}
              <div class="orders-list">${ordersHtml}</div>
              <div class="batch-actions">${dispatchBtn}</div>
            </div>
          `;
        })
        .join('');
    });

    renderStats();
  }

  function renderStats() {
    const s = engine.getStats();
    statsEl.innerHTML = `
      <div class="stat-card"><div class="label">Total Orders</div><div class="value">${s.totalOrders}</div></div>
      <div class="stat-card"><div class="label">Total Batches</div><div class="value accent">${s.totalBatches}</div></div>
      <div class="stat-card"><div class="label">Active (Open)</div><div class="value">${s.activeBatches}</div></div>
      <div class="stat-card"><div class="label">Ready for Pickup</div><div class="value amber">${s.readyBatches}</div></div>
      <div class="stat-card"><div class="label">Dispatched</div><div class="value green">${s.dispatchedBatches}</div></div>
      <div class="stat-card"><div class="label">Avg Items / Batch</div><div class="value accent">${s.avgItemsPerBatch}</div></div>
    `;
  }

  // ---------------- Event delegation for dispatch buttons ----------------
  zonesBoardEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.mark-dispatched');
    if (!btn) return;
    const id = btn.dataset.id;
    const batch = engine.markDispatched(id);
    if (batch) toast(`Batch #${batch.seq} (${ZONE_META[batch.zone].label}) marked as dispatched ✓`, 'dispatch');
    render();
  });

  // ---------------- Manual order form ----------------
  orderForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const zone = document.getElementById('zone-select').value;
    let customerName = document.getElementById('customer-name').value.trim();
    if (!customerName) customerName = NAMES[Math.floor(Math.random() * NAMES.length)];

    const items = Object.entries(selectedItems).map(([name, qty]) => ({ name, qty }));
    if (items.length === 0) {
      toast('Select at least one item before placing the order.', 'split');
      return;
    }

    const { batch, order } = engine.addOrder({ zone, customerName, items });
    const wasSplit = batch.orders.length === 1 && batch.seq > 1;
    toast(
      `New order from ${order.customerName} → ${ZONE_META[zone].label}, Batch #${batch.seq}${wasSplit ? ' (new batch — previous was full)' : ''}`,
      wasSplit ? 'split' : ''
    );

    // reset form
    document.getElementById('customer-name').value = '';
    Object.keys(selectedItems).forEach((k) => delete selectedItems[k]);
    renderChipState();
    render();
  });

  // ---------------- Auto simulator ----------------
  let simInterval = null;
  let simRunning = false;

  function generateRandomOrder() {
    const zone = Batching.ZONES[Math.floor(Math.random() * Batching.ZONES.length)];
    const name = NAMES[Math.floor(Math.random() * NAMES.length)];
    const itemCountTarget = 1 + Math.floor(Math.random() * 4); // 1-4 items per order
    const items = [];
    let remaining = itemCountTarget;
    const usedNames = new Set();
    while (remaining > 0) {
      let dish = MENU[Math.floor(Math.random() * MENU.length)];
      let tries = 0;
      while (usedNames.has(dish) && tries < 5) {
        dish = MENU[Math.floor(Math.random() * MENU.length)];
        tries++;
      }
      usedNames.add(dish);
      const qty = Math.min(remaining, 1 + Math.floor(Math.random() * 2));
      items.push({ name: dish, qty });
      remaining -= qty;
    }
    return { zone, customerName: name, items };
  }

  function simulateOneOrder() {
    const input = generateRandomOrder();
    const { batch, order } = engine.addOrder(input);
    const wasSplit = batch.orders.length === 1 && batch.seq > 1;
    toast(
      `${order.customerName} ordered in ${ZONE_META[input.zone].label} → Batch #${batch.seq}${wasSplit ? ' 🔀 auto-split!' : ''}`,
      wasSplit ? 'split' : ''
    );
    render();
  }

  function setSimRunning(on) {
    simRunning = on;
    if (on) {
      simToggleBtn.textContent = '⏸ Stop Simulation';
      simToggleBtn.className = 'btn btn-sim-on';
      simInterval = setInterval(() => {
        simulateOneOrder();
      }, 1800 + Math.random() * 1600);
    } else {
      simToggleBtn.textContent = '▶ Start Live Simulation';
      simToggleBtn.className = 'btn btn-sim-off';
      clearInterval(simInterval);
    }
  }

  simToggleBtn.addEventListener('click', () => setSimRunning(!simRunning));

  resetBtn.addEventListener('click', () => {
    if (!confirm('Reset the dashboard? This clears all current orders and batches.')) return;
    window.location.reload();
  });

  // ---------------- Clock + tick loop ----------------
  function tickClock() {
    clockEl.textContent = new Date().toLocaleTimeString('en-IN', { hour12: false });
  }

  // ---------------- Init ----------------
  buildZoneColumns();
  buildChips();
  renderChipState();
  render();
  tickClock();
  setInterval(() => {
    engine.tick();
    render();
    tickClock();
  }, 1000);

  // seed a few demo orders so the board isn't empty on load
  ['North', 'South', 'East'].forEach((zone) => {
    const n = NAMES[Math.floor(Math.random() * NAMES.length)];
    engine.addOrder({ zone, customerName: n, items: [{ name: MENU[Math.floor(Math.random() * MENU.length)], qty: 2 }] });
  });
  render();
})();

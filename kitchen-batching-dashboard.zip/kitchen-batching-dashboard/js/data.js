/**
 * data.js — display metadata + sample menu used to simulate incoming orders.
 * Zone KEYS must exactly match Batching.ZONES ('North','South','East','West','Central').
 */
(function (root) {
  const ZONE_META = {
    North: { label: 'Yelahanka', sub: 'North Zone', color: '#8B7CF6', icon: '🧭' },
    South: { label: 'Jayanagar', sub: 'South Zone', color: '#22C58B', icon: '🧭' },
    East: { label: 'Whitefield', sub: 'East Zone', color: '#38BDF8', icon: '🧭' },
    West: { label: 'Rajajinagar', sub: 'West Zone', color: '#F0965B', icon: '🧭' },
    Central: { label: 'MG Road', sub: 'Central Zone', color: '#F472B6', icon: '🧭' }
  };

  const MENU = [
    'Masala Dosa', 'Idli Sambar', 'Butter Chicken', 'Paneer Butter Masala',
    'Veg Biryani', 'Chicken Biryani', 'Filter Coffee', 'Gulab Jamun',
    'Chole Bhature', 'Veg Fried Rice', 'Cold Coffee', 'Samosa (2pc)',
    'Mysore Pak', 'Rava Upma', 'Chicken 65', 'Veg Manchurian'
  ];

  const NAMES = [
    'Aarav', 'Diya', 'Karthik', 'Sneha', 'Rohan', 'Ishita', 'Vikram', 'Ananya',
    'Manoj', 'Priya', 'Suresh', 'Divya', 'Arjun', 'Meera', 'Nikhil', 'Pooja',
    'Rahul', 'Kavya', 'Siddharth', 'Lakshmi'
  ];

  root.DashboardData = { ZONE_META, MENU, NAMES };
})(typeof window !== 'undefined' ? window : this);

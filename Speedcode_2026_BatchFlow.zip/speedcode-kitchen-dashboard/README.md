# BatchFlow — Speedcode 2026

A polished, dependency-free kitchen order batching dashboard built for the Speedcode 2026 hackathon.

## Run
1. Unzip the project.
2. Open `index.html` in any modern browser.
3. No server, npm, installation, or internet connection is required after the page loads.

## Core hackathon logic
- Orders are grouped by **zone**.
- Batches have a hard **5-item capacity**.
- When adding an order would push a batch above 5 items, the engine automatically starts a second batch for the same zone.
- Orders larger than 5 items are safely split across multiple batches.
- The dashboard shows active batches, zone load, incoming orders, and efficiency.

## Demo flow
1. Click **Simulate Order**.
2. Add 4–5 items to a busy zone.
3. Add another order that would exceed capacity.
4. Watch the batch queue split automatically.
5. Click **Auto-batch now** to demonstrate the optimization state.

## Presentation angle
BatchFlow is designed to communicate three things instantly:
**Zone affinity → rolling-window batching → hard capacity safety.**

The UI is intentionally dark, high-contrast, and operations-focused so judges can understand the concept within seconds.

const zones=["North","East","South","West"];
let orders=[
 {id:"BF-1048",zone:"North",items:2,time:"10:42:18"},
 {id:"BF-1047",zone:"East",items:4,time:"10:41:52"},
 {id:"BF-1046",zone:"North",items:1,time:"10:41:07"},
 {id:"BF-1045",zone:"South",items:3,time:"10:40:31"},
 {id:"BF-1044",zone:"West",items:2,time:"10:39:55"},
 {id:"BF-1043",zone:"East",items:1,time:"10:39:21"},
 {id:"BF-1042",zone:"North",items:2,time:"10:38:44"},
 {id:"BF-1041",zone:"South",items:4,time:"10:38:06"},
 {id:"BF-1040",zone:"West",items:3,time:"10:37:32"}
];
let sound=true, filter="All zones";

function makeBatches(){
 const result=[];
 zones.forEach(zone=>{
   const os=orders.filter(o=>o.zone===zone);
   let current=[], count=0, n=1;
   os.forEach(o=>{
     if(count+o.items>5 && current.length){ result.push({zone,id:`${zone.slice(0,2).toUpperCase()}-${n++}`,orders:current,count}); current=[];count=0; }
     if(o.items>5){
       let remain=o.items;
       while(remain>5){result.push({zone,id:`${zone.slice(0,2).toUpperCase()}-${n++}`,orders:[{...o,items:5}],count:5});remain-=5}
       if(remain){current.push({...o,items:remain});count+=remain}
     } else {current.push(o);count+=o.items}
   });
   if(current.length) result.push({zone,id:`${zone.slice(0,2).toUpperCase()}-${n++}`,orders:current,count});
 });
 return result;
}
function renderBatches(){
 const list=document.getElementById("batchList"), batches=makeBatches();
 list.innerHTML=batches.map(b=>{
   const pct=Math.min(100,b.count/5*100), ready=b.count>=5;
   return `<div class="batch"><div><div class="batch-zone">${b.zone} Zone</div><div class="batch-id">BATCH ${b.id}</div></div><div><div class="progress"><i style="width:${pct}%"></i></div><div class="status ${ready?"ready":""}">${ready?"CAPACITY REACHED":"Filling window · 5m"}</div></div><div class="batch-meta"><div class="batch-count">${b.count}<small>/5</small></div><div class="status ${ready?"ready":""}">${ready?"READY":"OPEN"}</div></div></div>`;
 }).join("");
 document.getElementById("activeBatches").textContent=batches.length;
}
function renderZones(){
 const counts=Object.fromEntries(zones.map(z=>[z,orders.filter(o=>o.zone===z).reduce((a,b)=>a+b.items,0)]));
 document.getElementById("zoneMap").innerHTML=zones.map(z=>`<div class="zone ${z.toLowerCase()} ${counts[z]>=6?"hot":""}"><strong>${z}</strong><span>${counts[z]} items queued</span></div>`).join("");
 document.getElementById("zoneSummary").innerHTML=zones.map(z=>`<div><b>${counts[z]}</b>${z}</div>`).join("");
}
function renderOrders(){
 const visible=filter==="All zones"?orders:orders.filter(o=>o.zone===filter);
 document.getElementById("orderTable").innerHTML=`<div class="order-row head"><span>Order</span><span>Zone</span><span>Items</span><span>Time</span></div>`+
 visible.slice(0,8).map(o=>`<div class="order-row"><span class="order-id">${o.id}</span><span class="order-zone"><i class="z-dot"></i>${o.zone}</span><span class="items-pill">${o.items} item${o.items>1?"s":""}</span><span class="order-time">${o.time}</span></div>`).join("");
}
function render(){renderBatches();renderZones();renderOrders();document.getElementById("ordersToday").textContent=38+Math.max(0,orders.length-9)}
function toast(title,text){
 document.getElementById("toastTitle").textContent=title;document.getElementById("toastText").textContent=text;
 const t=document.getElementById("toast");t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2800);
}
function now(){return new Date().toTimeString().slice(0,8)}
document.getElementById("simulateBtn").onclick=()=>document.getElementById("modal").classList.add("open");
document.getElementById("modalClose").onclick=()=>document.getElementById("modal").classList.remove("open");
document.getElementById("addOrder").onclick=()=>{
 const z=document.getElementById("newZone").value, items=Math.max(1,Math.min(12,+document.getElementById("newItems").value||1));
 orders.unshift({id:`BF-${1049+orders.length}`,zone:z,items,time:now()});
 document.getElementById("modal").classList.remove("open");render();
 const b=makeBatches().filter(x=>x.zone===z);const last=b[b.length-1];
 toast(items>5?"Capacity split applied":"Order batched",items>5?`${items} items safely split across capacity limits.`:`Added to ${z} zone · batch ${last.id}`);
};
document.getElementById("autoBatchBtn").onclick=()=>{render();toast("Batching optimized","All zones rebalanced against the 5-item capacity.");};
document.getElementById("focusBtn").onclick=()=>document.getElementById("batches").scrollIntoView({behavior:"smooth"});
document.getElementById("soundBtn").onclick=()=>{sound=!sound;document.getElementById("soundBtn").textContent=sound?"♬":"♩";toast(sound?"Sound enabled":"Sound muted","Dashboard preference updated.");};
document.getElementById("filterBtn").onclick=()=>{
 const idx=zones.indexOf(filter), next=idx<0?zones[0]:zones[(idx+1)%zones.length]; filter=filter==="All zones"?zones[0]:next;
 if(filter===zones[0]&&idx===zones.length-1) filter="All zones";
 document.getElementById("filterBtn").textContent=filter+" ▾";renderOrders();
};
setInterval(()=>document.getElementById("lastSync").textContent="Synced "+new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}),10000);
render();
